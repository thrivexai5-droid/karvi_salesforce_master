# KARVI Dashboard - PythonAnywhere Deployment Guide

## Prerequisites
- PythonAnywhere account (Hacker plan or higher for PostgreSQL)
- Project files uploaded to PythonAnywhere

## Step-by-Step Deployment

### 1. Upload Project Files
- Upload all project files to `/home/yourusername/karvi_salesforce_master`
- Ensure all files are in the correct directory structure

### 2. Set Up Virtual Environment
```bash
# Open Bash console on PythonAnywhere
cd ~/karvi_salesforce_master
python3.10 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. Configure Database
1. Go to PythonAnywhere Dashboard → Databases
2. Create a new PostgreSQL database named `karvi_dashboard`
3. Note down the database credentials:
   - Database name: `yourusername$karvi_dashboard`
   - Username: `yourusername`
   - Password: (set your password)
   - Host: `yourusername-xxxx.postgres.pythonanywhere-services.com`

### 4. Environment Configuration
1. Copy `.env.production` to `.env`
2. Update `.env` with your actual values:
   ```
   DEBUG=False
   SECRET_KEY=your-new-secret-key
   ALLOWED_HOST=yourusername.pythonanywhere.com
   DB_NAME=yourusername$karvi_dashboard
   DB_USER=yourusername
   DB_PASSWORD=your-database-password
   DB_HOST=yourusername-xxxx.postgres.pythonanywhere-services.com
   ```

### 5. Run Database Migrations
```bash
source venv/bin/activate
python manage.py migrate
python manage.py collectstatic --noinput
python manage.py createsuperuser
```

### 6. Configure Web App
1. Go to PythonAnywhere Dashboard → Web
2. Create a new web app (Manual configuration, Python 3.10)
3. Set configuration:
   - **Source code**: `/home/yourusername/karvi_salesforce_master`
   - **Working directory**: `/home/yourusername/karvi_salesforce_master`
   - **Virtualenv**: `/home/yourusername/karvi_salesforce_master/venv`

### 7. Configure WSGI File
1. Edit the WSGI configuration file in Web tab
2. Replace content with `wsgi_pythonanywhere.py` content
3. Update the path with your username

### 8. Configure Static Files
In the Web tab, add static files mapping:
- **URL**: `/static/`
- **Directory**: `/home/yourusername/karvi_salesforce_master/staticfiles/`

### 9. Configure Media Files (if needed)
- **URL**: `/media/`
- **Directory**: `/home/yourusername/karvi_salesforce_master/media/`

### 10. Final Steps
1. Click "Reload" button in Web tab
2. Visit your site: `https://yourusername.pythonanywhere.com`
3. Test login with superuser credentials

## Troubleshooting

### Common Issues:
1. **Import Errors**: Check virtual environment path
2. **Database Connection**: Verify database credentials in `.env`
3. **Static Files Not Loading**: Run `python manage.py collectstatic`
4. **500 Error**: Check error logs in PythonAnywhere

### Checking Logs:
- Error logs: Web tab → Log files
- Server logs: `/var/log/yourusername.pythonanywhere.com.error.log`

## Security Checklist
- [ ] DEBUG=False in production
- [ ] Strong SECRET_KEY generated
- [ ] Database password is secure
- [ ] ALLOWED_HOSTS configured correctly
- [ ] Static files collected
- [ ] Superuser account created

## Maintenance
- Regular backups of PostgreSQL database
- Monitor error logs
- Update dependencies periodically
- Keep Django and security packages updated

## Support
For issues, check:
1. PythonAnywhere help pages
2. Django documentation
3. Project error logs