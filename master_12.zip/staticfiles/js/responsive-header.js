/**
 * Responsive Header JavaScript with jQuery
 * Handles dynamic behavior for all screen sizes
 */

$(document).ready(function() {
    'use strict';
    
    // Configuration
    const config = {
        breakpoints: {
            xs: 0,
            sm: 576,
            md: 768,
            lg: 992,
            xl: 1200,
            xxl: 1400,
            headerCollapse: 1000,
            headerCompact: 1400
        },
        classes: {
            mobileToggle: '.mobile-nav-toggle',
            mobileNav: '#mobileNav',
            headerNav: '.header-nav',
            navLinks: '.nav-link-header, .nav-link-mobile',
            logoText: '.logo-text',
            userName: '.user-name',
            navSpans: '.nav-link-header span'
        },
        animations: {
            duration: 300,
            easing: 'ease-in-out'
        }
    };
    
    // State management
    let currentBreakpoint = getCurrentBreakpoint();
    let isMenuOpen = false;
    let resizeTimer = null;
    
    /**
     * Get current breakpoint based on window width
     */
    function getCurrentBreakpoint() {
        const width = $(window).width();
        
        if (width >= config.breakpoints.xxl) return 'xxl';
        if (width >= config.breakpoints.xl) return 'xl';
        if (width >= config.breakpoints.lg) return 'lg';
        if (width >= config.breakpoints.md) return 'md';
        if (width >= config.breakpoints.sm) return 'sm';
        return 'xs';
    }
    
    /**
     * Initialize responsive header functionality
     */
    function initResponsiveHeader() {
        setupMobileToggle();
        setupNavigationHighlighting();
        setupResponsiveElements();
        setupAccessibility();
        setupPerformanceOptimizations();
        
        // Initial setup
        handleBreakpointChange();
        
        console.log('Responsive header initialized');
    }
    
    /**
     * Setup mobile navigation toggle
     */
    function setupMobileToggle() {
        const $toggle = $(config.classes.mobileToggle);
        const $mobileNav = $(config.classes.mobileNav);
        
        $toggle.on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            toggleMobileMenu();
        });
        
        // Close mobile menu when clicking outside
        $(document).on('click', function(e) {
            if (isMenuOpen && !$(e.target).closest('.full-width-header').length) {
                closeMobileMenu();
            }
        });
        
        // Close mobile menu on escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' && isMenuOpen) {
                closeMobileMenu();
            }
        });
        
        // Close mobile menu when clicking on nav links
        $('.nav-link-mobile').on('click', function() {
            setTimeout(closeMobileMenu, 150);
        });
    }
    
    /**
     * Toggle mobile menu
     */
    function toggleMobileMenu() {
        const $toggle = $(config.classes.mobileToggle);
        const $mobileNav = $(config.classes.mobileNav);
        
        if (isMenuOpen) {
            closeMobileMenu();
        } else {
            openMobileMenu();
        }
    }
    
    /**
     * Open mobile menu
     */
    function openMobileMenu() {
        const $toggle = $(config.classes.mobileToggle);
        const $mobileNav = $(config.classes.mobileNav);
        
        $toggle.addClass('active');
        $mobileNav.addClass('show');
        isMenuOpen = true;
        
        // Add aria attributes
        $toggle.attr('aria-expanded', 'true');
        $mobileNav.attr('aria-hidden', 'false');
        
        // Focus management
        $mobileNav.find('.nav-link-mobile').first().focus();
        
        // Prevent body scroll on mobile
        if ($(window).width() <= config.breakpoints.md) {
            $('body').addClass('mobile-menu-open');
        }
    }
    
    /**
     * Close mobile menu
     */
    function closeMobileMenu() {
        const $toggle = $(config.classes.mobileToggle);
        const $mobileNav = $(config.classes.mobileNav);
        
        $toggle.removeClass('active');
        $mobileNav.removeClass('show');
        isMenuOpen = false;
        
        // Update aria attributes
        $toggle.attr('aria-expanded', 'false');
        $mobileNav.attr('aria-hidden', 'true');
        
        // Restore body scroll
        $('body').removeClass('mobile-menu-open');
    }
    
    /**
     * Setup navigation highlighting
     */
    function setupNavigationHighlighting() {
        const currentPath = window.location.pathname;
        const $navLinks = $(config.classes.navLinks);
        
        // Remove all active classes first
        $('.nav-item-header, .nav-item-mobile').removeClass('active');
        
        // Find and highlight current page
        $navLinks.each(function() {
            const href = $(this).attr('href');
            if (href && href !== 'javascript:void(0)' && href !== '#') {
                if (currentPath === href || currentPath.includes(href)) {
                    $(this).closest('.nav-item-header, .nav-item-mobile').addClass('active');
                }
            }
        });
        
        // Fallback: highlight dashboard if no match found
        if (!$('.nav-item-header.active, .nav-item-mobile.active').length) {
            $('.nav-item-header, .nav-item-mobile').first().addClass('active');
        }
    }
    
    /**
     * Setup responsive elements behavior
     */
    function setupResponsiveElements() {
        // Handle logo text visibility
        function updateLogoText() {
            const width = $(window).width();
            const $logoText = $(config.classes.logoText);
            
            if (width <= config.breakpoints.lg) {
                $logoText.fadeOut(200);
            } else {
                $logoText.fadeIn(200);
            }
        }
        
        // Handle username visibility
        function updateUserName() {
            const width = $(window).width();
            const $userName = $(config.classes.userName);
            
            if (width <= config.breakpoints.lg) {
                $userName.fadeOut(200);
            } else {
                $userName.fadeIn(200);
            }
        }
        
        // Handle navigation text visibility
        function updateNavText() {
            const width = $(window).width();
            const $navSpans = $(config.classes.navSpans);
            
            if (width <= config.breakpoints.headerCompact) {
                $navSpans.fadeOut(200);
            } else {
                $navSpans.fadeIn(200);
            }
        }
        
        // Handle desktop/mobile navigation visibility
        function updateNavigationVisibility() {
            const width = $(window).width();
            const $headerNav = $(config.classes.headerNav);
            const $mobileToggle = $(config.classes.mobileToggle);
            
            if (width <= config.breakpoints.headerCollapse) {
                $headerNav.hide();
                $mobileToggle.show();
            } else {
                $headerNav.show();
                $mobileToggle.hide();
                closeMobileMenu(); // Close mobile menu if open
            }
        }
        
        // Store functions for later use
        window.responsiveHeaderFunctions = {
            updateLogoText,
            updateUserName,
            updateNavText,
            updateNavigationVisibility
        };
    }
    
    /**
     * Setup accessibility features
     */
    function setupAccessibility() {
        // Add ARIA labels
        $(config.classes.mobileToggle).attr({
            'aria-label': 'Toggle navigation menu',
            'aria-expanded': 'false',
            'role': 'button'
        });
        
        $(config.classes.mobileNav).attr({
            'aria-hidden': 'true',
            'role': 'navigation',
            'aria-label': 'Mobile navigation menu'
        });
        
        // Add keyboard navigation
        $('.nav-link-header, .nav-link-mobile').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                $(this)[0].click();
            }
        });
        
        // Focus management for mobile menu
        $(config.classes.mobileNav).on('keydown', function(e) {
            const $focusableElements = $(this).find('a, button, [tabindex]:not([tabindex="-1"])');
            const $firstElement = $focusableElements.first();
            const $lastElement = $focusableElements.last();
            
            if (e.key === 'Tab') {
                if (e.shiftKey) {
                    if (document.activeElement === $firstElement[0]) {
                        e.preventDefault();
                        $lastElement.focus();
                    }
                } else {
                    if (document.activeElement === $lastElement[0]) {
                        e.preventDefault();
                        $firstElement.focus();
                    }
                }
            }
        });
    }
    
    /**
     * Setup performance optimizations
     */
    function setupPerformanceOptimizations() {
        // Debounced resize handler
        $(window).on('resize', function() {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(function() {
                const newBreakpoint = getCurrentBreakpoint();
                if (newBreakpoint !== currentBreakpoint) {
                    currentBreakpoint = newBreakpoint;
                    handleBreakpointChange();
                }
            }, 150);
        });
        
        // Throttled scroll handler for header effects
        let scrollTimer = null;
        $(window).on('scroll', function() {
            if (scrollTimer) return;
            
            scrollTimer = setTimeout(function() {
                handleScroll();
                scrollTimer = null;
            }, 16); // ~60fps
        });
        
        // Preload critical resources
        preloadCriticalResources();
    }
    
    /**
     * Handle breakpoint changes
     */
    function handleBreakpointChange() {
        if (window.responsiveHeaderFunctions) {
            window.responsiveHeaderFunctions.updateLogoText();
            window.responsiveHeaderFunctions.updateUserName();
            window.responsiveHeaderFunctions.updateNavText();
            window.responsiveHeaderFunctions.updateNavigationVisibility();
        }
        
        // Close mobile menu on breakpoint change
        if (currentBreakpoint !== 'xs' && currentBreakpoint !== 'sm' && currentBreakpoint !== 'md') {
            closeMobileMenu();
        }
        
        // Update body class for CSS targeting
        $('body').removeClass('breakpoint-xs breakpoint-sm breakpoint-md breakpoint-lg breakpoint-xl breakpoint-xxl')
                 .addClass(`breakpoint-${currentBreakpoint}`);
        
        console.log(`Breakpoint changed to: ${currentBreakpoint}`);
    }
    
    /**
     * Handle scroll events
     */
    function handleScroll() {
        const scrollTop = $(window).scrollTop();
        const $header = $('.full-width-header');
        
        // Add/remove scrolled class for styling
        if (scrollTop > 10) {
            $header.addClass('scrolled');
        } else {
            $header.removeClass('scrolled');
        }
        
        // Auto-hide mobile menu on scroll (mobile only)
        if (isMenuOpen && $(window).width() <= config.breakpoints.md && scrollTop > 50) {
            closeMobileMenu();
        }
    }
    
    /**
     * Preload critical resources
     */
    function preloadCriticalResources() {
        // Preload commonly used icons
        const iconUrls = [
            'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css'
        ];
        
        iconUrls.forEach(url => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.as = 'style';
            link.href = url;
            document.head.appendChild(link);
        });
    }
    
    /**
     * Public API
     */
    window.ResponsiveHeader = {
        openMobileMenu,
        closeMobileMenu,
        toggleMobileMenu,
        getCurrentBreakpoint,
        config
    };
    
    // Initialize everything
    initResponsiveHeader();
    
    // Add smooth transitions after initial load
    setTimeout(function() {
        $('.full-width-header, .header-content, .nav-link-header, .nav-link-mobile').addClass('transitions-enabled');
    }, 100);
});

// CSS for body scroll lock and transitions
const additionalCSS = `
<style>
body.mobile-menu-open {
    overflow: hidden;
    position: fixed;
    width: 100%;
}

.transitions-enabled {
    transition: all 0.3s ease-in-out !important;
}

.full-width-header.scrolled {
    box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
}

/* Smooth mobile menu animation */
.mobile-nav-menu {
    transition: all 0.3s ease-in-out !important;
    max-height: 0;
    overflow: hidden;
}

.mobile-nav-menu.show {
    max-height: 500px;
}

/* Focus styles for accessibility */
.nav-link-header:focus,
.nav-link-mobile:focus,
.mobile-nav-toggle:focus {
    outline: 2px solid #3b82f6 !important;
    outline-offset: 2px !important;
}

/* Loading state */
.header-loading {
    opacity: 0.7;
    pointer-events: none;
}

/* High performance animations */
.nav-link-header,
.nav-link-mobile,
.notification-icon,
.profile-avatar {
    will-change: transform;
}

/* Reduced motion support */
@media (prefers-reduced-motion: reduce) {
    .transitions-enabled,
    .mobile-nav-menu {
        transition: none !important;
    }
}
</style>
`;

// Inject additional CSS
document.head.insertAdjacentHTML('beforeend', additionalCSS);